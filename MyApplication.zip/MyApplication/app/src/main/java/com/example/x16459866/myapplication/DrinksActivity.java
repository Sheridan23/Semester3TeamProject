package com.example.x16459866.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class DrinksActivity extends AppCompatActivity {

    private Button Bnt_D1;
    private Button Bnt_D2;
    private Button dBackBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks);

        Bnt_D1 = findViewById(R.id.Bnt_D1);
        Bnt_D1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Toast.makeText(DrinksActivity.this,"Added to Order",Toast.LENGTH_SHORT).show();

            }

        });


            Bnt_D2 = (Button) findViewById(R.id.Bnt_D2);
        Bnt_D2.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    Toast.makeText(DrinksActivity.this,"Added to Order",Toast.LENGTH_SHORT).show();

                }
        });

        dBackBtn = findViewById(R.id.dBackBtn);
        dBackBtn = findViewById(R.id.dBackBtn);
        dBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DrinksActivity.this, Main2Activity.class);
                startActivity(i);
            }
        });
    }
}

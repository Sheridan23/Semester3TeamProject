package com.example.x16459866.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FoodActivity extends AppCompatActivity {
    private Button Bnt_F1;
    private Button Bnt_F2;
    private Button fBackBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);



        Bnt_F1 = findViewById(R.id.Bnt_F1);
        Bnt_F1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Toast.makeText(FoodActivity.this,"Added to Cart",Toast.LENGTH_SHORT).show();

            }

        });


        Bnt_F2 = (Button) findViewById(R.id.Bnt_F2);
        Bnt_F2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Toast.makeText(FoodActivity.this,"Added to Cart",Toast.LENGTH_SHORT).show();

            }
        });

        fBackBtn = findViewById(R.id.fBackBtn);
        fBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FoodActivity.this, Main2Activity.class);
                startActivity(i);
            }
        });
    }
}
